_____________________Asger Arendt Langhoff's readme_______________________

Programmet jeg har lavet er en udgave af det klassiske spil, Atari Breakout.

Spillet starter på en screen 0 der byder en velkommen. Man skal dernæst 
trykke på venstre museknap for at komme videre. 

Når man har trykket kommer man til en skærm hvor x-koordinaten af din mus er 
forbundet med den "paddle" der er i bunden af skærmen. Du styrer dermed din 
paddle med musen og skal brugen den til at slå bolden op i de mursten man 
skal ødelægge.

Hvis bolden kommer forbi din paddle taber du spillet. Du får 1 point for 
hver murstendu ødelægger, men hver gang du har ramt 20 går boldens hastighed 
op og murstenene kommer tilbage.

Man kan starte spillet forfra ved at trykke på venstre museknap, når man taber.

Programmet samt alle lektier kan findes i github på enten: 
https://github.com/AsgerLanghoff/2019_IntroToPrograming_StudentsWork 

eller
https://github.com/AsgerLanghoff/MED1_IntroToProgramming